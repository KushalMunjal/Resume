import AS501.AS501Client;
import Models.Client.AS501ClientRequest;
import Models.Client.AS501ClientResponse;
import Models.Client.Request.AS501RequestDataBody;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileInputStream;

public class Main {
    public static void main(String[] args) {
        String json =  "{ \"requestId\": \"IND2550fdf\", \"sourceSystemName\": \"FINACLE\", \"purpose\": \"03\", \"customerList\": [ { \"ekycOTPbased\": \"0\", \"segment\": \"3\", \"segmentStartDate\": \"11-Feb-2022\", \"status\": \"Active\", \"effectiveDate\": \"15-Nov-2022\", \"minor\": \"0\", \"maritalStatus\": \"M\", \"occupationType\": \"SE\", \"occupationTypeOther\": \"\", \"natureOfBusinessOther\": \"Marketing Firm\", \"companyIdentificationNumber\": \"\", \"companyRegistrationNumber\": \"\", \"companyRegistrationCountry\": \"\", \"globalIntermediaryIdentificationNumber\": \"\", \"kycAttestationType\": \"1\", \"kycDateOfDeclaration\": \"11-Mar-2021\", \"kycPlaceOfDeclaration\": \"Mumbai\", \"kycVerificationDate\": \"11-Mar-2021\", \"kycEmployeeName\": \"Aditi Jadhav\", \"kycEmployeeDesignation\": \"Manager\", \"kycVerificationBranch\": \"Mumbai\", \"kycEmployeeCode\": \"6546514\", \"listed\": \"\", \"applicationRefNumber\": \"AJNPC45568\", \"documentRefNumber\": \"DOCREF5722\", \"regAMLRisk\": \"1\", \"regAMLRiskLastRiskReviewDate\": \"21-Jan-2019\", \"regAMLRiskNextRiskReviewDate\": \"21-Mar-2025\", \"incomeRange\": \"2\", \"exactIncome\": 250000.5, \"incomeCurrency\": \"INR\", \"incomeEffectiveDate\": \"11-Feb-2022\", \"incomeDescription\": \"Total income of a month\", \"incomeDocument\": \"TaxReturns,CashFlowStatement\", \"exactNetworth\": 1000000.0, \"networthCurrency\": \"INR\", \"networthEffectiveDate\": \"11-Feb-2019\", \"networthDescription\": \"Total networth income of a year\", \"networthDocument\": \"NetworthCertificate, BalanceSheet\", \"familyCode\": \"FMC18779\", \"channel\": \"2\", \"contactPersonFirstName1\": \"\", \"contactPersonMiddleName1\": \"\", \"contactPersonLastName1\": \"\", \"contactPersonDesignation1\": \"\", \"contactPersonFirstName2\": \"\", \"contactPersonMiddleName2\": \"\", \"contactPersonLastName2\": \"\", \"contactPersonDesignation2\": \"\", \"contactPersonMobileISD\": \"\", \"contactPersonMobileNo\": \"\", \"contactPersonMobileISD2\": \"\", \"contactPersonMobileNo2\": \"\", \"contactPersonEmailId1\": \"\", \"contactPersonEmailId2\": \"\", \"commencementDate\": \"\", \"maidenPrefix\": \"\", \"maidenFirstName\": \"\", \"maidenMiddleName\": \"\", \"maidenLastName\": \"\", \"relatedPersonCountforCKYC\": 0, \"proofOfIdSubmitted\": \"Passport\", \"products\": \"MF,LI\", \"natureOfBusiness\": \" Jewellers ,GemPreciousMetalsOrStoneDealers,Oth\", \"educationalQualification\": \"1, 4\", \"countryOfOperations\": \"IND, USA\", \"regAMLRiskSpecialCategoryDtoList\": [ { \"regAMLRiskSpecialCategory\": \"2\", \"regAMLRiskSpecialCategoryStartDate\": \"10-Jan-2019\" } ], \"relatedPersonList\": [], \"customerRelationDtoList\": [], \"constitutionType\": \"1\", \"constitutionTypeId\": 0, \"sourceSystemCustomerCode\": \"2550\", \"sourceSystemCustomerCreationDate\": \"11-Feb-2022\", \"uniqueIdentifier\": \"UI2550\", \"prefix\": \"Dr\", \"firstName\": \"Hansraj\", \"middleName\": \"Gitesh\", \"lastName\": \"Hemani\", \"fatherPrefix\": \"Mr\", \"fatherFirstName\": \"Gitesh\", \"fatherMiddleName\": \"Sambhaji\", \"fatherLastName\": \"Hemani\", \"spousePrefix\": \"Mrs\", \"spouseFirstName\": \"Sonali\", \"spouseMiddleName\": \"Hansraj\", \"spouseLastName\": \"Hemani\", \"motherPrefix\": \"Mrs\", \"motherFirstName\": \"Jayaprabha\", \"motherMiddleName\": \"Gitesh\", \"motherLastName\": \"Hemani\", \"gender\": \"01\", \"dateofBirth\": \"11-Feb-1995\", \"workEmail\": \"HansrajHemani1@Tss.co.in\", \"personalEmail\": \"HansrajHemani1@gmail.com\", \"personalMobileISD\": \"91\", \"personalMobileNumber\": \"9950438478\", \"workMobileISD\": \"91\", \"workMobileNumber\": \"7330067911\", \"permanentAddressCountry\": \"IND\", \"permanentAddressZipCode\": \"403707\", \"permanentAddressLine1\": \"Gokulnagri, Chawl no 15, Room no- 101\", \"permanentAddressLine2\": \"Near MJ College\", \"permanentAddressLine3\": \"Behind RK Hotel, Mumbai\", \"permanentAddressDistrict\": \"Mumbai\", \"permanentAddressCity\": \"Mumbai\", \"permanentAddressState\": \"MH\", \"permanentAddressDocument\": \"Passport\", \"permanentAddressDocumentOthersValue\": \"\", \"correspondenceAddressCountry\": \"IND\", \"correspondenceAddressZipCode\": \"403702\", \"correspondenceAddressLine1\": \"Mamta Nagar, Gavdevi, Flat 101\", \"correspondenceAddressLine2\": \"Koliwada\", \"correspondenceAddressLine3\": \"Mahim West\", \"correspondenceAddressDistrict\": \"Mumbai\", \"correspondenceAddressCity\": \"Mumbai\", \"correspondenceAddressState\": \"MH\", \"correspondenceAddressDocument\": \"UtilityBill2m\", \"countryOfResidence\": \"IND\", \"countryOfBirth\": \"IND\", \"birthCity\": \"Mumbai\", \"passportIssueCountry\": \"IND\", \"passportNumber\": \"PASS38142\", \"passportExpiryDate\": \"02-Feb-2025\", \"voterIdNumber\": \"VOTE78456\", \"drivingLicenseNumber\": \"DL935152\", \"drivingLicenseExpiryDate\": \"20-Sep-2025\", \"aadhaarNumber\": \"784690271234\", \"aadhaarVaultReferenceNumber\": \"11483398602\", \"nregaNumber\": \"MH-02-12038/90\", \"nprLetterNumber\": \"NPR25689\", \"directorIdentificationNumber\": \"\", \"formSixty\": \"0\", \"pan\": \"ADDPP9547L\", \"ckycNumber\": \"80080070068592\", \"identityDocument\": \"\", \"politicallyExposed\": \"PEP\", \"adverseReputationDetails\": \"Involved in Money Laundering Crimes\", \"notes\": \"Onboarding of Customer\", \"tags\": \"2,3\", \"screeningProfile\": \"CUSSP129\", \"screeningreportwhennil\": \"1\", \"riskProfile\": null, \"adverseReputation\": \"1\", \"adverseReputationClassification\": \"1, 2\", \"taxDetailDtoList\": [ { \"taxResidencyCountry\": \"IND\", \"taxIdentificationNumber\": \"TIN2550\", \"taxResidencyStartDate\": \"01-Oct-2022\", \"taxResidencyEndDate\": \"01-Oct-2026\" } ], \"politicallyExposedClassification\": \"1, 2\", \"citizenships\": \"IND, GBR\", \"nationalities\": \"IND, GBR\", \"documents\": [] } ] }";
        String password = "marwadi";
        FileInputStream publicPath = null,privatePath = null;
        try {
            publicPath = new FileInputStream("H:/Temporary/Vaibhav.Soni/Marwadi/ValidDocument/public.cer");
            privatePath = new FileInputStream("H:/Temporary/Vaibhav.Soni/Marwadi/ValidDocument/private.pfx");
            byte[] publicKey = publicPath.readAllBytes();
            byte[] privateKey = privatePath.readAllBytes();
            AS501ClientRequest as501ClientRequest = new AS501ClientRequest();
            as501ClientRequest.data = new Main().getRequestBody();
            as501ClientRequest.publicKey = publicKey;
            as501ClientRequest.privateKey = privateKey;
            as501ClientRequest.password = password;
            as501ClientRequest.url = "https://tenantdev1.tssconsultancy.com:5309/AS501";
            as501ClientRequest.apiToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJBcGlTdWJzY3JpcHRpb25JZCI6IjEiLCJUZW5hbnRJZGVudGlmaWVyIjoiUGFydGhNYXN0ZXJJZGVudGlmaWVyIiwiQXBpSWQiOiIxIiwiRW5jcnlwdGlvblByb3ZpZGVySWQiOiI2IiwiQWdlbmN5SWQiOiI4IiwiZXhwIjoxODY1NzAxODAwLCJpc3MiOiJ0cmFja3dpenpTYWFTR2xvYmFsIiwiYXVkIjoiYW5ndWxhckNsaWVudCJ9.5PSrgz4EVjLMpke50BYG7K0RFWapR83ktCC9s_q4_Zw";
            as501ClientRequest.requestId = "a795a235-60d2-4f59-b6f6-078f6648fd71";
            AS501Client as501Client = new AS501Client();
            AS501ClientResponse result = as501Client.Execute(as501ClientRequest);
            Gson gson  = new Gson();
            System.out.println(gson.toJson(result));
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                if(publicPath != null) {
                    publicPath.close();
                }
                if(privatePath != null) {
                    privatePath.close();
                }
            }catch(Exception e) {

            }

        }

    }
    private AS501RequestDataBody getRequestBody(){
        try {
            FileInputStream file = new FileInputStream("D:/RequestData.txt");
            byte[] data = file.readAllBytes();
            String requestBody = new String(data);
            return new Gson().fromJson(requestBody, AS501RequestDataBody.class);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}