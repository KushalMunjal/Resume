package Exception;

public class ValidationException extends Exception{
    public ValidationException(String exceptionMesssage) {
        super(exceptionMesssage);
    }
}
