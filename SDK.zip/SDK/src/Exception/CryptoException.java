package Exception;

public class CryptoException extends Exception{
    public CryptoException(String exceptionMesssage) {
        super(exceptionMesssage);
    }
}
