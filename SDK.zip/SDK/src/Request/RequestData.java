package Request;

import Models.Internal.API.AS501APIRequest;
import Models.Internal.API.AS501APIResponse;
import Models.Internal.AS501InternalBody;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class RequestData {

    public AS501APIResponse makeRequest(AS501InternalBody as501InternalBody) throws Exception {
        AS501APIRequest as501APIRequest = new AS501APIRequest();
        as501APIRequest.RequestId = "a795a235-60d2-4f59-b6f6-078f6648fd71";
        as501APIRequest.encryptedData = as501InternalBody.encryptedData;
        as501APIRequest.encryptionKey = as501InternalBody.encryptionKey;
        as501APIRequest.signature = as501InternalBody.signature;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.disableHtmlEscaping().create();
        String requestBody = gson.toJson(as501APIRequest);
        try{
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(as501InternalBody.clientRequest.url))
                    .timeout(Duration.ofSeconds(10))
                    .header("Content-Type", "application/json")
                    .header("domain", as501InternalBody.clientRequest.url)
                    .header("cluster", "CL1_User")
                    .header("apiToken", as501InternalBody.clientRequest.apiToken)
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return gson.fromJson(response.body(), AS501APIResponse.class);
        }catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }





//    public String MakeRequest(AS501ClientRequest as501ClientRequest, AS501ClientResponse as501ClientResponse, String json, PublicKey publicKey, PrivateKey privateKey){
//        try{
//            Gson gson = new Gson();
//            HttpClient client = HttpClient.newHttpClient();
//            HttpRequest request = HttpRequest.newBuilder()
//                    .uri(new URI(as501ClientRequest.url))
//                    .timeout(Duration.ofSeconds(5))
//                    .header("Content-Type", "application/json")
//                    .header("domain", as501ClientRequest.url)
//                    .header("cluster", "CL1_User")
//                    .header("apiToken", as501ClientRequest.apiToken)
//                    .POST(HttpRequest.BodyPublishers.ofString(json))
//                    .build();
//
//            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
//            if(response==null){
//                as501ClientResponse.errorMessage = "ConectionTimeout";
//            }
//
//            HttpHeaders headers = response.headers();
//
//            String responseString = response.body();
//
//            JsonObject responseData = gson.fromJson(responseString, JsonObject.class);
//
//            String encryptedData = responseData.get("encryptedData").getAsString();
//            String encryptionKey = responseData.get("encryptionKey").getAsString();
//            String signature = responseData.get("signature").getAsString();
//
//            String verifierData = encryptedData + encryptionKey;
//
//            Decryption decryption = new Decryption();
//            String decryptedData = decryption.decryptData(verifierData,encryptedData,encryptionKey,signature,(PrivateKey) privateKey,publicKey);
//
//            JsonObject respondeddata = gson.fromJson(decryptedData, JsonObject.class);
//
//            String overallstatus = respondeddata.get("OverallStatus").getAsString();
//            as501ClientResponse.response = decryptedData;
//            return overallstatus;
//        }catch (Exception e){
//            e.getMessage();
//            return null;
//        }
    }

