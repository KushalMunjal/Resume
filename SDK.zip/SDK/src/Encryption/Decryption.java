package Encryption;

import Exception.CryptoException;
import Models.Internal.AS501InternalBody;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;

public class Decryption {
    public String decryptSymmetrically(String encryptedData,Key key) throws CryptoException{
        try{
            Cipher cipher =  Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decoded = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
            return new String(decoded);
        }catch (Exception e){
            e.printStackTrace();
            throw new CryptoException(e.getMessage());
        }
    }
    public Key decryptAsymmetrically(String encryptedKey, AS501InternalBody as501InternalBody) throws CryptoException{
        try {
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE,as501InternalBody.privateKey);
            byte[] encodedKey = cipher.doFinal(Base64.getDecoder().decode(encryptedKey));
            return new SecretKeySpec(Base64.getDecoder().decode(encodedKey),"AES");
        } catch (Exception e) {
            e.printStackTrace();
            throw new CryptoException(e.getMessage());
        }
    }
}

