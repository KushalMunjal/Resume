package Encryption;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class Decryption {

    /*
        Following are the steps to decrypt and read the response:
        1.Verify the signature in Response using the Public Key of the Sender.
        2.Decode the Session Key from the Response.
        3.Decrypt the above Session Key by Receiver’s Private Key using RSA (Asymmetric Algorithm)
        4.Decode the data in Response.
        5.Decrypt the data by Session Key (derived from above) using AES (Symmetric Algorithm).

    */
    private static String DecryptedData;

    public static String decryptData(String verifierData, String encryptedData, String encryptedKey, String signature, PrivateKey receiverPrivatekey, PublicKey senderPublicKey) {
        try {
            //Verify the signature in Response using the Public Key of the Sender.
            boolean signatureVerified = SecureSignature.verifySignature(verifierData, signature, senderPublicKey);
            if (signatureVerified) {
                byte[] encryptedSymmetricKey = encryptedKey.getBytes();
                byte[] encryptedDataBytes = encryptedData.getBytes();
                byte[] encodedsymetrickey = Base64.getDecoder().decode(encryptedSymmetricKey);
                byte[] encodeddata = Base64.getDecoder().decode(encryptedDataBytes);
                byte[] decryptedSessionKey = decryptSymmetricKey(encodedsymetrickey,receiverPrivatekey);
                byte[] encodedsessionkey = Base64.getDecoder().decode(decryptedSessionKey);
                String decryptedData = decryptDataWithSymmetricKey(encodeddata,encodedsessionkey);

                return decryptedData;
            } else {
                System.out.println("Signature Verification Failed");
                return "Signature verification failed.";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error during decryption: " + e.getMessage();
        }
    }

    private static byte[] decryptSymmetricKey(byte[] encryptedSymmetricKey, PrivateKey receiverPrivatekey) {
        try {
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE, receiverPrivatekey);
            return cipher.doFinal(encryptedSymmetricKey);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    //  Decrypt Data with Symmetric Key
    private static String decryptDataWithSymmetricKey(byte[] encryptedData, byte[] key) {
        try {
            SecretKeySpec keySpec = new SecretKeySpec(key,"AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            byte[] decrypteddata = cipher.doFinal(encryptedData);
            return new String(decrypteddata);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

