package Encryption;

import Exception.CryptoException;
import Models.Client.Request.AS501RequestDataBody;
import Models.Internal.AS501InternalBody;
import com.google.gson.Gson;

import javax.crypto.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class Encryption {
    public static final int sessionkey_size = 256;

    public SecretKey generateSessionKey() throws NoSuchAlgorithmException {

        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(sessionkey_size);
            return keyGen.generateKey();
        } catch (Exception e) {
            throw new RuntimeException("Error Generating SessionKey:",e);
        }
    }
    public String encryptUsingSymmetricKey(AS501RequestDataBody as501RequestDataBody, SecretKey sessionKey)throws NoSuchPaddingException,NoSuchAlgorithmException,
            InvalidKeyException, BadPaddingException,IllegalBlockSizeException, CryptoException{
        try {
            String info = new Gson().toJson(as501RequestDataBody);
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE,sessionKey);
            byte[] encryptedbyte = cipher.doFinal(info.getBytes());
            return Base64.getEncoder().encodeToString(encryptedbyte);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CryptoException(e.getMessage());
        }

    }
    public String encryptAsymmetrically(AS501InternalBody as501InternalBody) throws CryptoException{
        String encryptedResponse = null;
        try{
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, as501InternalBody.publicKey);
            byte[] encodedSessionKey = cipher.doFinal(Base64.getEncoder().encode(as501InternalBody.sesssionKey.getEncoded()));
            encryptedResponse = Base64.getEncoder().encodeToString(encodedSessionKey);

        }catch(Exception e){
            throw new CryptoException(e.getMessage());
        }
        return encryptedResponse;
    }

}
