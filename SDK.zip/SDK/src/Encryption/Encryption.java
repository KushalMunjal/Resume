package Encryption;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

public class Encryption {
/*

    Following are the steps to be followed for encryption:
    1.Generate a Session Key of 256 bits.
    2.Encrypt the request data using AES (Symmetric 128 bits) algorithm with the above generated Session Key
    3.Encode the above encrypted data to Base64 string.
    4.Encrypt the session key using the Public Key of the Receiver, using RSA (Asymmetric Algorithm).
    5.Encode the above encrypted Session Key to Base64 string.
    6.Combine the encrypted data and encrypted session key into a string and then sign that string using the sender's private key.
    7.Add this encrypted and encoded data, session Key and signature to the request.
    8.Note: Key sizes acceptable: - 1024,2048 bits

*/

    private static final int sessionkey_size = 256;
    public static String encryptData(String requestData, PublicKey receiverPublicKey, PrivateKey senderPrivateKey) throws Exception{

        try{
            String requestid1 = "a795a235-60d2-4f59-b6f6-078f6648fd71";

            // Generate a SessionKey of 256 bits
            SecretKey sessionKey = generateSessionKey();

            //Encrypt the Request data using AES using Sessionkey
            byte[] encryptData = encryptWithAES(requestData, sessionKey);

            //Encoding the Encrypted data to Base64 string
            String encodedData = tobase64Encode(encryptData);

            byte[] encodedsessionkey = sessionkeytobase64Encode(sessionKey.getEncoded());
            //Encrypt the Sessionkey using the public key of receiver
            byte[] encryptedSessionKey = encryptWithRSA(encodedsessionkey,receiverPublicKey);

            //Encode encrypted sessionkey to base64 string
            String encodedSessionKey = tobase64Encode(encryptedSessionKey);


            //Combining the Encrypted Data and Encrypted SessionKey into String
            String combinedString = encodedData + encodedSessionKey;

            // Convert the combined string to byte array using UTF-8 or UTF-16 encoding
            byte[] combinedBytes = combinedString.getBytes(StandardCharsets.UTF_16LE); // or StandardCharsets.UTF_16

            // Sign the combined string using the sender's private key
            String encodedSignature = SecureSignature.signData(encodedData, encodedSessionKey, combinedBytes, senderPrivateKey);
            System.out.println("EncryptedData: "+encodedData);
            System.out.println("EncryptedKey: "+encodedSessionKey);
            System.out.println("Signature: "+encodedSignature);

            Map<String, String> resultMap = new LinkedHashMap<>();
            resultMap.put("requestId", requestid1);
            resultMap.put("encryptedData", encodedData);
            resultMap.put("encryptionKey", encodedSessionKey);
            resultMap.put("signature", encodedSignature);



            // Convert the map to JSON format
            Gson gson = new GsonBuilder().disableHtmlEscaping().create();
            String jsonResult = gson.toJson(resultMap);

            return jsonResult;

        }catch(Exception e){
            e.printStackTrace();
            return null;
        }

    }
    private static SecretKey generateSessionKey() throws NoSuchAlgorithmException {

        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(sessionkey_size);
            return keyGen.generateKey();
        } catch (Exception e) {
            throw new RuntimeException("Error Generating Key:",e);
        }
    }

    private static byte[] encryptWithAES(String requestData, SecretKey sessionKey) throws Exception {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE,sessionKey);
            return cipher.doFinal(requestData.getBytes());
        } catch (Exception e) {
            throw new RuntimeException("Error Encrypting AES:",e);
        }
    }

    private static String tobase64Encode(byte[] encryptData) {
        return Base64.getEncoder().encodeToString(encryptData);
    }
    private static byte[] sessionkeytobase64Encode(byte[] sessionkey) {
        return Base64.getEncoder().encode(sessionkey);
    }

    private static byte[] encryptWithRSA(byte[] encoded, PublicKey receiverPublicKey) {
        try {
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE,receiverPublicKey);
            return cipher.doFinal(encoded);
        } catch (Exception e) {
            throw new RuntimeException("Error Encrypting RSA:",e);
        }
    }

}
