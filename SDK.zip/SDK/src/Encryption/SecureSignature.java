package Encryption;

import Exception.CryptoException;
import Models.Internal.API.AS501APIResponse;
import Models.Internal.AS501InternalBody;

import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Base64;

public class SecureSignature {
    public String signData(AS501InternalBody as501InternalBody) throws CryptoException{
        try {
            String combinedString = as501InternalBody.encryptedData + as501InternalBody.encryptionKey;
            byte[] combinedBytes = combinedString.getBytes(StandardCharsets.UTF_16LE);
            Signature signature = Signature.getInstance("SHA512withRSA");
            signature.initSign(as501InternalBody.privateKey);
            signature.update(combinedBytes);
            return Base64.getEncoder().encodeToString(signature.sign());
        } catch (Exception e) {
            e.printStackTrace();
            throw new CryptoException(e.getMessage());
        }
    }
    public boolean verifySignature(AS501APIResponse as501APIResponse, PublicKey publicKey) throws CryptoException{
        try {
            String combinedString = as501APIResponse.encryptedData + as501APIResponse.encryptionKey;
            byte[] data = combinedString.getBytes(StandardCharsets.UTF_16LE);
            Signature verifier = Signature.getInstance("SHA512withRSA");
            verifier.initVerify(publicKey);
            verifier.update(data);
            return verifier.verify(Base64.getDecoder().decode(as501APIResponse.signature));
        } catch (Exception e) {
            e.printStackTrace();
            throw new CryptoException(e.getMessage());
        }
    }
}
