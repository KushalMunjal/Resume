package Models.Client;

public class MainRequestDataField {

    private String RequestID;
    private String SourceSystemName;
    private String ApiToken;
    private String Purpose;
    private String SessionKey;

    private int requestIDlength = 200;
    private int apiTokenlength = 100;
    private int purposelength = 2;
    private int sessionKeylength = 100;

    public MainRequestDataField(String requestID, String sourceSystemName, String apiToken, String purpose, String sessionKey) {
        RequestID = requestID;
        SourceSystemName = sourceSystemName;
        ApiToken = apiToken;
        Purpose = purpose;
        SessionKey = sessionKey;
    }

    public String getRequestID() { return RequestID;}

    public void setRequestID(String requestID) {
        if(requestID.length() <= requestIDlength){
            RequestID = requestID;
        }
        else{
            throw new IllegalArgumentException("RequestID Length Exceeds the maximum allowed length");
        }

    }

    public String getSourceSystemName() {
        return SourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        SourceSystemName = sourceSystemName;
    }

    public String getApiToken() {
        return ApiToken;
    }

    public void setApiToken(String apiToken) {
        if(apiToken.length() <= apiTokenlength){
            ApiToken = apiToken;
        }

    }

    public String getPurpose() {
        return Purpose;
    }

    public void setPurpose(String purpose) {
        Purpose = purpose;
    }

    public String getSessionKey() {
        return SessionKey;
    }

    public void setSessionKey(String sessionKey) {
        SessionKey = sessionKey;
    }
}
