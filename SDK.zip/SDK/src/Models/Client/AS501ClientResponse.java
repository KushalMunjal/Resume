package Models.Client;

public class AS501ClientResponse {
}
