package Models.Client;

public class AS501ClientResponse {
    public String errorMessage;
    public RequestStatus requestStatus;
    public DecryptedAPIResponse.AS501ResponseDto response;
}
