package Models.Client;

import java.util.List;

public class DecryptedAPIResponse {
    public static class AS501ResponseDto
    {
        public String OverallStatus;
        public List<CustomerResponse> CustomerResponse;
    }
    public static  class BaseResponse
    {
        public String ValidationOutcome;
        public List<PurposeResponse> PurposeResponse;
    }
    public static class CustomerResponse extends CustomerBaseResp
    {
        public List<CustomerBaseResp> RelatedPersonResponse;
        public List<RPRelationResponse> RelatedPersonRelationResponse;
    }
    public static class CustomerBaseResp extends BaseResponse
    {
        public String SourceSystemCustomerCode;
    }

    public static  class RPRelationResponse extends BaseResponse
    {
        public String SourceSystemCustomerCode;
        public String RelatedPersonSourceSystemCode;
        public String RelationCode;
    }

    public static class PurposeResponse
    {
        public String Purpose;
        public String PurposeCode;
        public Object Data;
        public String ValidationCode;
        public String ValidationDescription;
        public int ValidationFailureCount;
    }
}
