package Models.Client;

public enum RequestStatus {
    ValidationError,
    CryptoOrKeyError,
    UnexpectedError,
    AcceptedByTrackWizz,
    RejectedByTrackWizz
}

