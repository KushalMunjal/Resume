package Models.Client.Request;

import java.util.List;

public class AS501RequestDataBody {
    public String requestId;
    public String sourceSystemName;
    public String purpose;
    public List<CustomerRequestBody> customerList;
//	public String GUID;
}
