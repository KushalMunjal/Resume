package Models.Client.Request;

import java.util.List;

public class BaseRequestBody {
    public String constitutionType;

    public long constitutionTypeId;

    public String sourceSystemName;

    public String sourceSystemCustomerCode;

    public String sourceSystemCustomerCreationDateString;

    public String sourceSystemCustomerCreationDate;

    public String uniqueIdentifier;
    // public String systemGeneratedId;

    public String prefix;

    public int prefixId;

    public String firstName;

    public String middleName;

    public String lastName;

    public String fatherPrefix;

    public int fatherPrefixId;

    public String fatherFirstName;

    public String fatherMiddleName;

    public String fatherLastName;

    public String spousePrefix;

    public int spousePrefixId;

    public String spouseFirstName;

    public String spouseMiddleName;

    public String spouseLastName;

    public String motherPrefix;

    public int motherPrefixId;

    public String motherFirstName;

    public String motherMiddleName;

    public String motherLastName;

    public String gender;

    public int genderId;

    public String dateOfBirthString;

    public String dateOfBirth;
    public String workEmail;

    public String personalEmail;
    public String permanentAddressCountry;

    public int permanentAddrssCountryId;

    public String permanentAddressZipCode;

    public int permanentAddressZipCodeId;

    public String permanentAddressLine1;

    public String permanentAddressLine2;

    public String permanentAddressLine3;

    public String permanentAddressDistrict;

    public int permanentAddressDistrictId;

    public String permanentAddressCity;

    public int permanentAddressCityId;

    public String permanentAddressState;
    public int permanentAddressStateId;
    public String permanentAddressDocument;
    public int permanentAddressDocumentId;
    public String permanentAddressDocumentOthersValue;
    public String correspondenceAddressCountry;
    public int correspondenceAddressCountryId;
    public String correspondenceAddressZipCode;
    public int correspondenceAddressZipCodeId;
    public String correspondenceAddressLine1;
    public String correspondenceAddressLine2;
    public String correspondenceAddressLine3;
    public String correspondenceAddressDistrict;
    public int correspondenceAddressDistrictId;
    public String correspondenceAddressCity;
    public int correspondenceAddressCityId;
    public String correspondenceAddressState;
    public int correspondenceAddressStateId;
    public String correspondenceAddressDocument;
    public int correspondenceAddressDocumentId;

    public String countryOfResidence;

    public int countryOfResidenceId;
    public String countryOfBirth;

    public int countryOfBirthId;
    public String birthCity;

    public int birthCityId;
    public String passportIssueCountry;
    public int passportIssueCountryId;
    public String passportNumber;
    public String passportExpiryDateString;
    public String passportExpiryDate;

    public String voterIdNumber;
    public String drivingLicenseNumber;
    public String drivingLicenseExpiryDateString;
    public String drivingLicenseExpiryDate;

    public String aadhaarNumber;
    public String aadhaarVaultReferenceNumber;
    public String nregaNumber;

    public String nprLetterNumber;

    public String directorIdentificationNumber;

    public String formSixty;

    public int formSixtyId;

    public String pan;

    public String ckycNumber;

    public String identityDocument;

    public String identityDocumentId;

    public String politicallyExposed;

    public int politicallyExposedId;

    public String adverseReputationString;

    public String adverseReputationDetails;

    public String otes;

    public String tags;

    public List<Integer> tagIdList;

    public String screeningProfile;

    public String riskProfile;

    public String adverseReputation;

    public int adverseReputationId;
    public String adverseReputationClassification;
    public List<Integer> adverseReputationClassificationIdList;

    public List<TaxDetailRequestBody> taxDetailDtoList;
    public String politicallyExposedClassification;
    public List<Integer> politicallyExposedClassificationIdList;
    public String citizenships;
    public List<Integer> citizenshipsId;
    public String nationalities;
    public List<Integer> nationalitiesId;
    // public List<DocumentDto> DocumentDtoList;
}
