package Models.Client.Request;

public class TaxDetailRequestBody {

    //public long Id;
    public String taxResidencyCountry;
    public int taxResidencyCountryId ;
    public String taxIdentificationNumber;
    public String taxResidencyStartDateString;
    public  String taxResidencyStartDate;
    public  String taxResidencyEndDateString;
    public  String taxResidencyEndDate;
}
