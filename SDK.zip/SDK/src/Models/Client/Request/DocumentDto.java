package Models.Client.Request;

public class DocumentDto {
}
