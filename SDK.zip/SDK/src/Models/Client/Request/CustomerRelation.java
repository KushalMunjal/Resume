package Models.Client.Request;

import java.util.Date;

public class CustomerRelation {

    public String requestId ;
    // public String SystemGeneratedId ;
    public String customerSystemGeneratedId ;
    public String customerSourceSystemCode ;
    //    public String rPSystemGeneratedId ;
    public String relatedPersonSourceSystemCode ;
    public int relationCodeId ;
    public String relationCode ;
    public String relationStartDateString ;
    public String startDate ;
    public String relationEndDateString ;
    public Date endDate ;
    public double shareHoldingPercentage ;
    //  public String notes ;
}
