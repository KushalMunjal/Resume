package Models.Client.Request;

import java.util.Date;

public class RegAMLRiskSpecialCategory {
    //public int Id ;
    public String regAMLRiskSpecialCategory ;
    public int regAmlRiskSpecialCategoryId ;
    public String regAMLRiskSpecialCategoryStartDateString ;
    public Date regAmlRiskSpecialCategoryStartDate ;
}
