package Models.Client;

import Encryption.Encryption;
import Encryption.Decryption;
import Encryption.SecureSignature;
import Models.API.AS501APIRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class HttpRequestData {
    private String encryptedData;
    private String encryptionKey;
    private String signature;
    private String requestId;

    public static void main(String[] args) {
        Gson gson = new Gson();
        Encryption e1 = new Encryption();
        AS501APIRequest a1 = new AS501APIRequest();
        AS501APIRequest.Customer c1 = new AS501APIRequest.Customer();
        AS501APIRequest.RelatedPerson rp1 = new AS501APIRequest.RelatedPerson();
        AS501APIRequest.CustomerRelationDto cr1 = new AS501APIRequest.CustomerRelationDto();
        AS501APIRequest.TaxDetailDto t1 = new AS501APIRequest.TaxDetailDto();
        AS501APIRequest.Document d1 = new AS501APIRequest.Document();
        AS501APIRequest.RegAMLRiskSpecialCategoryDto r1 = new AS501APIRequest.RegAMLRiskSpecialCategoryDto();

        a1.setRequestId("IND2550fdf");
        a1.setSourceSystemName("FINACLE");
        a1.setPurpose("01");

        c1.setEkycOTPbased("0");
        c1.setSegment("3");
        c1.setSegmentStartDate("11-Feb-2022");
        c1.setStatus("Active");
        c1.setEffectiveDate("15-Nov-2022");
        c1.setMinor("0");
        c1.setMaritalStatus("M");
        c1.setOccupationType("SE");
        c1.setOccupationTypeOther("");
        c1.setNatureOfBusinessOther("Marketing Firm");
        c1.setCompanyIdentificationNumber("");
        c1.setCompanyRegistrationNumber("");
        c1.setCompanyRegistrationCountry("");
        c1.setGlobalIntermediaryIdentificationNumber("");
        c1.setKycAttestationType("1");
        c1.setKycDateOfDeclaration("11-Mar-2021");
        c1.setKycPlaceOfDeclaration("Mumbai");
        c1.setKycEmployeeName("Aditi Jadhav");
        c1.setKycEmployeeDesignation("Manager");
        c1.setKycVerificationBranch("Mumbai");
        c1.setKycEmployeeCode("6546514");
        c1.setListed("");
        c1.setApplicationRefNumber("AJNPC45568");
        c1.setDocumentRefNumber("DOCREF5722");
        c1.setRegAMLRisk("1");
        c1.setRegAMLRiskLastRiskReviewDate("21-Jan-2019");
        c1.setRegAMLRiskNextRiskReviewDate("21_Mar-2025");
        c1.setIncomeRange("2");
        c1.setExactIncome(250000.5);
        c1.setIncomeCurrency("INR");
        c1.setIncomeEffectiveDate("11-Feb-2022");
        c1.setIncomeDescription("Total income of a month");
        c1.setIncomeDocument("TaxReturns,CashFlowStatement");
        c1.setExactNetworth(1000000.0);
        c1.setNetworthCurrency("INR");
        c1.setNetworthDescription("Total income of a Year");
        c1.setNetworthDocument("NetworthCertificate, BalanceSheet");
        c1.setFamilyCode("FMC18779");
        c1.setChannel("2");
        c1.setContactPersonFirstName1("");
        c1.setContactPersonMiddleName1("");
        c1.setContactPersonLastName1("");
        c1.setContactPersonDesignation1("");
        c1.setContactPersonFirstName2("");
        c1.setContactPersonMiddleName2("");
        c1.setContactPersonLastName2("");
        c1.setContactPersonDesignation2("");
        c1.setContactPersonMobileISD("");
        c1.setContactPersonMobileNo("");
        c1.setContactPersonMobileISD2("");
        c1.setContactPersonMobileNo2("");
        c1.setContactPersonEmailId1("");
        c1.setContactPersonEmailId2("");
        c1.setCommencementDate("");
        c1.setMaidenPrefix("");
        c1.setMaidenFirstName("");
        c1.setMaidenMiddleName("");
        c1.setMaidenLastName("");
        c1.setRelatedPersonCountforCKYC(0);
        c1.setProofOfIdSubmitted("Passport");
        c1.setProducts("MF,LI");
        c1.setNatureOfBusiness("Jewellers ,GemPreciousMetalsOrStoneDealers,Oth");
        c1.setEducationalQualification("1,4");
        c1.setCountryOfOperations("IND,USA");

        r1.setRegAMLRiskSpecialCategory("2");
        r1.setRegAMLRiskSpecialCategoryStartDate("10-Jan-2019");


        c1.setCitizenships("IND, GBR");
        c1.setNationalities("IND, GBR");



        t1.setTaxResidencyCountry("IND");
        t1.setTaxIdentificationNumber("TIN2550");


        List<AS501APIRequest.Customer> customerList = new ArrayList<>();
        customerList.add(c1);
        a1.setCustomerList(customerList);

        List<AS501APIRequest.RegAMLRiskSpecialCategoryDto> riskCategoryList = new ArrayList<>();
        riskCategoryList.add(r1);
        c1.setRegAMLRiskSpecialCategoryDtoList(riskCategoryList);

        List<AS501APIRequest.TaxDetailDto> taxdetailList = new ArrayList<>();
        taxdetailList.add(t1);
        c1.setTaxDetailDtoList(taxdetailList);

        List<AS501APIRequest.Document> docs = new ArrayList<>();
        docs.add(d1);
        c1.setDocuments(docs);

        List<AS501APIRequest.RelatedPerson> relatedprs = new ArrayList<>();
        relatedprs.add(rp1);
        c1.setRelatedPersonList(relatedprs);

        List<AS501APIRequest.CustomerRelationDto> cd = new ArrayList<>();
        cd.add(cr1);
        c1.setCustomerRelationDtoList(cd);

        try{


            String json =  "{ \"requestId\": \"IND2550fdf\", \"sourceSystemName\": \"FINACLE\", \"purpose\": \"03\", \"customerList\": [ { \"ekycOTPbased\": \"0\", \"segment\": \"3\", \"segmentStartDate\": \"11-Feb-2022\", \"status\": \"Active\", \"effectiveDate\": \"15-Nov-2022\", \"minor\": \"0\", \"maritalStatus\": \"M\", \"occupationType\": \"SE\", \"occupationTypeOther\": \"\", \"natureOfBusinessOther\": \"Marketing Firm\", \"companyIdentificationNumber\": \"\", \"companyRegistrationNumber\": \"\", \"companyRegistrationCountry\": \"\", \"globalIntermediaryIdentificationNumber\": \"\", \"kycAttestationType\": \"1\", \"kycDateOfDeclaration\": \"11-Mar-2021\", \"kycPlaceOfDeclaration\": \"Mumbai\", \"kycVerificationDate\": \"11-Mar-2021\", \"kycEmployeeName\": \"Aditi Jadhav\", \"kycEmployeeDesignation\": \"Manager\", \"kycVerificationBranch\": \"Mumbai\", \"kycEmployeeCode\": \"6546514\", \"listed\": \"\", \"applicationRefNumber\": \"AJNPC45568\", \"documentRefNumber\": \"DOCREF5722\", \"regAMLRisk\": \"1\", \"regAMLRiskLastRiskReviewDate\": \"21-Jan-2019\", \"regAMLRiskNextRiskReviewDate\": \"21-Mar-2025\", \"incomeRange\": \"2\", \"exactIncome\": 250000.5, \"incomeCurrency\": \"INR\", \"incomeEffectiveDate\": \"11-Feb-2022\", \"incomeDescription\": \"Total income of a month\", \"incomeDocument\": \"TaxReturns,CashFlowStatement\", \"exactNetworth\": 1000000.0, \"networthCurrency\": \"INR\", \"networthEffectiveDate\": \"11-Feb-2019\", \"networthDescription\": \"Total networth income of a year\", \"networthDocument\": \"NetworthCertificate, BalanceSheet\", \"familyCode\": \"FMC18779\", \"channel\": \"2\", \"contactPersonFirstName1\": \"\", \"contactPersonMiddleName1\": \"\", \"contactPersonLastName1\": \"\", \"contactPersonDesignation1\": \"\", \"contactPersonFirstName2\": \"\", \"contactPersonMiddleName2\": \"\", \"contactPersonLastName2\": \"\", \"contactPersonDesignation2\": \"\", \"contactPersonMobileISD\": \"\", \"contactPersonMobileNo\": \"\", \"contactPersonMobileISD2\": \"\", \"contactPersonMobileNo2\": \"\", \"contactPersonEmailId1\": \"\", \"contactPersonEmailId2\": \"\", \"commencementDate\": \"\", \"maidenPrefix\": \"\", \"maidenFirstName\": \"\", \"maidenMiddleName\": \"\", \"maidenLastName\": \"\", \"relatedPersonCountforCKYC\": 0, \"proofOfIdSubmitted\": \"Passport\", \"products\": \"MF,LI\", \"natureOfBusiness\": \" Jewellers ,GemPreciousMetalsOrStoneDealers,Oth\", \"educationalQualification\": \"1, 4\", \"countryOfOperations\": \"IND, USA\", \"regAMLRiskSpecialCategoryDtoList\": [ { \"regAMLRiskSpecialCategory\": \"2\", \"regAMLRiskSpecialCategoryStartDate\": \"10-Jan-2019\" } ], \"relatedPersonList\": [], \"customerRelationDtoList\": [], \"constitutionType\": \"1\", \"constitutionTypeId\": 0, \"sourceSystemCustomerCode\": \"2550\", \"sourceSystemCustomerCreationDate\": \"11-Feb-2022\", \"uniqueIdentifier\": \"UI2550\", \"prefix\": \"Dr\", \"firstName\": \"Hansraj\", \"middleName\": \"Gitesh\", \"lastName\": \"Hemani\", \"fatherPrefix\": \"Mr\", \"fatherFirstName\": \"Gitesh\", \"fatherMiddleName\": \"Sambhaji\", \"fatherLastName\": \"Hemani\", \"spousePrefix\": \"Mrs\", \"spouseFirstName\": \"Sonali\", \"spouseMiddleName\": \"Hansraj\", \"spouseLastName\": \"Hemani\", \"motherPrefix\": \"Mrs\", \"motherFirstName\": \"Jayaprabha\", \"motherMiddleName\": \"Gitesh\", \"motherLastName\": \"Hemani\", \"gender\": \"01\", \"dateofBirth\": \"11-Feb-1995\", \"workEmail\": \"HansrajHemani1@Tss.co.in\", \"personalEmail\": \"HansrajHemani1@gmail.com\", \"personalMobileISD\": \"91\", \"personalMobileNumber\": \"9950438478\", \"workMobileISD\": \"91\", \"workMobileNumber\": \"7330067911\", \"permanentAddressCountry\": \"IND\", \"permanentAddressZipCode\": \"403707\", \"permanentAddressLine1\": \"Gokulnagri, Chawl no 15, Room no- 101\", \"permanentAddressLine2\": \"Near MJ College\", \"permanentAddressLine3\": \"Behind RK Hotel, Mumbai\", \"permanentAddressDistrict\": \"Mumbai\", \"permanentAddressCity\": \"Mumbai\", \"permanentAddressState\": \"MH\", \"permanentAddressDocument\": \"Passport\", \"permanentAddressDocumentOthersValue\": \"\", \"correspondenceAddressCountry\": \"IND\", \"correspondenceAddressZipCode\": \"403702\", \"correspondenceAddressLine1\": \"Mamta Nagar, Gavdevi, Flat 101\", \"correspondenceAddressLine2\": \"Koliwada\", \"correspondenceAddressLine3\": \"Mahim West\", \"correspondenceAddressDistrict\": \"Mumbai\", \"correspondenceAddressCity\": \"Mumbai\", \"correspondenceAddressState\": \"MH\", \"correspondenceAddressDocument\": \"UtilityBill2m\", \"countryOfResidence\": \"IND\", \"countryOfBirth\": \"IND\", \"birthCity\": \"Mumbai\", \"passportIssueCountry\": \"IND\", \"passportNumber\": \"PASS38142\", \"passportExpiryDate\": \"02-Feb-2025\", \"voterIdNumber\": \"VOTE78456\", \"drivingLicenseNumber\": \"DL935152\", \"drivingLicenseExpiryDate\": \"20-Sep-2025\", \"aadhaarNumber\": \"784690271234\", \"aadhaarVaultReferenceNumber\": \"11483398602\", \"nregaNumber\": \"MH-02-12038/90\", \"nprLetterNumber\": \"NPR25689\", \"directorIdentificationNumber\": \"\", \"formSixty\": \"0\", \"pan\": \"ADDPP9547L\", \"ckycNumber\": \"80080070068592\", \"identityDocument\": \"\", \"politicallyExposed\": \"PEP\", \"adverseReputationDetails\": \"Involved in Money Laundering Crimes\", \"notes\": \"Onboarding of Customer\", \"tags\": \"2,3\", \"screeningProfile\": \"CUSSP129\", \"screeningreportwhennil\": \"1\", \"riskProfile\": null, \"adverseReputation\": \"1\", \"adverseReputationClassification\": \"1, 2\", \"taxDetailDtoList\": [ { \"taxResidencyCountry\": \"IND\", \"taxIdentificationNumber\": \"TIN2550\", \"taxResidencyStartDate\": \"01-Oct-2022\", \"taxResidencyEndDate\": \"01-Oct-2026\" } ], \"politicallyExposedClassification\": \"1, 2\", \"citizenships\": \"IND, GBR\", \"nationalities\": \"IND, GBR\", \"documents\": [] } ] }";
//            String json = gson.toJson(a1);
            System.out.println(json);
            FileInputStream publicKeyInput = new FileInputStream("H:/Temporary/Vaibhav.Soni/Marwadi/ValidDocument/public.cer");
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            X509Certificate publicCertificate = (X509Certificate)certificateFactory.generateCertificate(publicKeyInput);
            PublicKey publicKey = publicCertificate.getPublicKey();

            FileInputStream privateKeyInput = new FileInputStream("H:/Temporary/Vaibhav.Soni/Marwadi/ValidDocument/private.pfx");
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            char[] password = "marwadi".toCharArray();
            keyStore.load(privateKeyInput,password);
            String alias = keyStore.aliases().nextElement();
            Key privateKey = keyStore.getKey(alias,password);

            String jsondata = e1.encryptData(json,publicKey,(PrivateKey) privateKey);

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("https://tenantdev1.tssconsultancy.com:5309/AS501"))
                    .header("Content-Type", "application/json")
                    .header("domain", "https://tenantdev1.tssconsultancy.com:5309")
                    .header("cluster", "CL1_User")
                    .header("apiToken", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJBcGlTdWJzY3JpcHRpb25JZCI6IjEiLCJUZW5hbnRJZGVudGlmaWVyIjoiUGFydGhNYXN0ZXJJZGVudGlmaWVyIiwiQXBpSWQiOiIxIiwiRW5jcnlwdGlvblByb3ZpZGVySWQiOiI2IiwiQWdlbmN5SWQiOiI4IiwiZXhwIjoxODY1NzAxODAwLCJpc3MiOiJ0cmFja3dpenpTYWFTR2xvYmFsIiwiYXVkIjoiYW5ndWxhckNsaWVudCJ9.5PSrgz4EVjLMpke50BYG7K0RFWapR83ktCC9s_q4_Zw")
                    .POST(HttpRequest.BodyPublishers.ofString(jsondata))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println(jsondata);
            System.out.println(response.body());
            HttpHeaders headers = response.headers();
            headers.map().forEach((k, v) -> System.out.println(k + ":" + v));
            System.out.println(response.statusCode());


            String responseString = response.body();
            TypeToken<HashMap<String,Object>> token = new TypeToken<>() {};
            HashMap<String,Object> responseData =  gson.fromJson(responseString,token.getType());
            String encryptedData = (String) responseData.get("encryptedData");
            String encryptionKey = (String) responseData.get("encryptionKey");
            String signature = (String) responseData.get("signature");
            SecureSignature sc = new SecureSignature();
            String verifierData = encryptedData + encryptionKey;
//            boolean data = sc.verifySignature(verifierData,signature,publicKey);
            Decryption dec1 = new Decryption();
            String data = dec1.decryptData(verifierData,encryptedData,encryptionKey,signature,(PrivateKey) privateKey,publicKey);
            System.out.println("-----------------"+data);
        }catch (Exception e){
                e.printStackTrace();
            }

    }

}
