package Models.Client;

public class RelationDataFields {
    String CustomerSourceSystemCode;
    String RelatedPersonSourceSystemCode;
    String RelationCode;
    String RelationStartDate;
    String RelationEndDate;
    String ShareHoldingPercentage;
    String RelationNotes;

}
