package Models.Client;

import Models.Client.Request.AS501RequestDataBody;

public class AS501ClientRequest {
    public AS501RequestDataBody data;
    public byte[] publicKey;
    public byte[] privateKey;
    public String password;
    public String url;
    public String apiToken;
    public String requestId;

}
