package Models.Internal.API;

import Models.Internal.API.Response.AS501Response;
import Models.Internal.JsonEncryptedDto;

import java.util.List;

public class AS501APIResponse extends JsonEncryptedDto {
    public String ResponseId;
    public String validationCode;
    public String validationDescription;
    public List<AS501Response> DecryptedData;
}