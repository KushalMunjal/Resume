package Models.Internal.API.Response;

public class PurposeResponse {
    public String Purpose;
    public String PurposeCode;
    public Object Data;
    public String ValidationCode;
    public String ValidationDescription;
    public int ValidationFailureCount;
}
