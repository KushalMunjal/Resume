package Models.Internal.API.Response;

import java.util.List;

public class AS501Response {
    public String OverallStatus;
    public List<CustomerResponse> CustomerResponse;
}
