package Models.Internal.API.Response;

import java.util.List;

public class BaseResponse {
    public String ValidationOutcome;
    public List<PurposeResponse> PurposeResponse;
}
