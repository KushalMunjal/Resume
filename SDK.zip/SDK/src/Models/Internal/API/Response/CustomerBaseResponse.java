package Models.Internal.API.Response;

public class CustomerBaseResponse extends BaseResponse {
    public String SourceSystemCustomerCode;
}