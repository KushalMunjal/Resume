package Models.Internal.API.Response;

public class RPRelationResponse extends BaseResponse{
    public String SourceSystemCustomerCode;
    public String RelatedPersonSourceSystemCode;
    public String RelationCode;
}
