package Models.Internal.API.Response;

import java.util.List;

public class CustomerResponse {
    public List<CustomerBaseResponse> RelatedPersonResponse;
    public List<RPRelationResponse> RelatedPersonRelationResponse;
}
