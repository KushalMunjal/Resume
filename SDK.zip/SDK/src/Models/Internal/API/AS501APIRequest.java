package Models.Internal.API;

import Models.Internal.JsonEncryptedDto;

public class AS501APIRequest extends JsonEncryptedDto {
    public String RequestId;
}