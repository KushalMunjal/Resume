package Models.Internal;

import Models.Client.AS501ClientRequest;

import javax.crypto.SecretKey;
import java.security.PrivateKey;
import java.security.PublicKey;

public class AS501InternalBody extends JsonEncryptedDto {
    public AS501ClientRequest clientRequest;
    public PrivateKey privateKey;
    public SecretKey sesssionKey;
    public PublicKey publicKey;
}
