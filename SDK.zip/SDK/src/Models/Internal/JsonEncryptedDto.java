package Models.Internal;

public class JsonEncryptedDto {
    public String encryptionKey;
    public String encryptedData;
    public String signature;
}
