package AS501;

import Encryption.Decryption;
import Encryption.Encryption;
import Encryption.SecureSignature;
import Exception.CryptoException;
import Exception.ValidationException;
import Models.Client.AS501ClientRequest;
import Models.Client.AS501ClientResponse;
import Models.Client.DecryptedAPIResponse;
import Models.Client.RequestStatus;
import Models.Internal.API.AS501APIResponse;
import Models.Internal.AS501InternalBody;
import Request.RequestData;
import com.google.gson.Gson;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.ByteArrayInputStream;
import java.security.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;

public class AS501Client {

    private Encryption encryption = null;
    private Decryption decryption = null;
    private SecureSignature signature = null;
    private RequestData requestData = null;
    public AS501Client(){
        encryption = new Encryption();
        decryption = new Decryption();
        signature = new SecureSignature();
        requestData = new RequestData();
    }


    public AS501ClientResponse Execute(AS501ClientRequest as501ClientRequest){

        AS501ClientResponse as501ClientResponse  = new AS501ClientResponse();
        AS501InternalBody internalBody = new AS501InternalBody();
        internalBody.clientRequest = as501ClientRequest;

        try{
            validateInputs(as501ClientRequest);

            ByteArrayInputStream inputStream = new ByteArrayInputStream(as501ClientRequest.publicKey);
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate)cf.generateCertificate(inputStream);

            PublicKey publicKey1 = cert.getPublicKey();

            X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(publicKey1.getEncoded());
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            Key publicKey = keyFactory.generatePublic(x509EncodedKeySpec);

            ByteArrayInputStream inputStream1 = new ByteArrayInputStream(as501ClientRequest.privateKey);
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load( inputStream1,as501ClientRequest.password.toCharArray());
            String alias = keyStore.aliases().nextElement().toString();
            PrivateKey privateKey = (PrivateKey) keyStore.getKey(alias, as501ClientRequest.password.toCharArray());

            internalBody.publicKey = (PublicKey) publicKey;
            internalBody.privateKey = (PrivateKey) privateKey;

            fillRequestBody(internalBody);

            AS501APIResponse response = requestData.makeRequest(internalBody);

            if(response.validationCode != null || response.validationDescription != null) {
                throw new ValidationException("Error: " + response.validationDescription);
            }

            if(!signature.verifySignature(response, (PublicKey) publicKey)) {
                throw new Exception("Signature is not matched");
            }
            Key sessionKey = decryption.decryptAsymmetrically(response.encryptionKey, internalBody);
            String rawResponse = decryption.decryptSymmetrically(response.encryptedData, sessionKey);
            as501ClientResponse.response = new Gson().fromJson(rawResponse, DecryptedAPIResponse.AS501ResponseDto.class);
            as501ClientResponse.requestStatus =  as501ClientResponse.response.OverallStatus.equals("RejectedByTW")
                    ?  RequestStatus.RejectedByTrackWizz
                    : RequestStatus.AcceptedByTrackWizz;

        }catch (ValidationException e) {
            as501ClientResponse.requestStatus = RequestStatus.ValidationError;
            as501ClientResponse.errorMessage = e.getMessage();
        }
        catch(CryptoException e) {
            as501ClientResponse.requestStatus  = RequestStatus.CryptoOrKeyError;
            as501ClientResponse.errorMessage = e.getMessage();
        }
        catch(Exception e) {
            as501ClientResponse.requestStatus = RequestStatus.UnexpectedError;
            as501ClientResponse.errorMessage = e.getMessage();
        }

        return as501ClientResponse;
    }
    private void fillRequestBody(AS501InternalBody internalBody)throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, BadPaddingException, IllegalBlockSizeException, CryptoException{
        internalBody.sesssionKey = encryption.generateSessionKey();
        internalBody.encryptedData = encryption.encryptUsingSymmetricKey(internalBody.clientRequest.data,internalBody.sesssionKey);
        internalBody.encryptionKey = encryption.encryptAsymmetrically(internalBody);
        internalBody.signature = signature.signData(internalBody);

    }
    private void validateInputs(AS501ClientRequest request) throws ValidationException {
        StringBuilder builder = new StringBuilder();
        char delimiter = ',';
        if(request.publicKey == null || request.publicKey.length == 0) {
            builder.append("Public Key should not be empty.");
            builder.append(delimiter);
        }
        if(request.privateKey == null || request.privateKey.length == 0) {
            builder.append("Private Key should not be empty.");
            builder.append(delimiter);
        }
        if(request.password == null || request.password.length() == 0 ) {
            builder.append("Password for Private key is  required");
            builder.append(delimiter);
        }
        if(request.url == null || request.url.length() == 0) {
            builder.append("Endpoint Url cannot be empty");
            builder.append(delimiter);
        }
        if(request.apiToken == null || request.apiToken.length() == 0) {
            builder.append("Api Token cannot be empty");
            builder.append(delimiter);
        }

        if(builder.length() > 0)
            throw new ValidationException(builder.toString().substring(0, builder.length() -1 ));

    }
}
